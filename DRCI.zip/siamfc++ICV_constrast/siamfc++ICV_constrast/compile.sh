# complie evaluation toolkit
cd siamfcpp/evaluation/vot_benchmark
bash make.sh
