
def _init():
    global dist_cmprate
    dist_cmprate = {}

def set_value(value):
    # _global_dict[key]=value
    backbone_cmp = value[0]
    neck_cmp = value[1]
    head_cmp = value[2]
    dist_cmprate['backbone_conv1'] = backbone_cmp
    dist_cmprate['backbone_conv2'] = backbone_cmp
    dist_cmprate['backbone_conv3'] = backbone_cmp
    dist_cmprate['backbone_conv4'] = backbone_cmp
    dist_cmprate['backbone_conv5'] = backbone_cmp

    dist_cmprate['tranf_c_x'] = neck_cmp
    dist_cmprate['tranf_r_x'] = neck_cmp
    dist_cmprate['tranf_c_z_k'] = neck_cmp
    dist_cmprate['tranf_r_z_k'] = neck_cmp

    dist_cmprate['head_bbox_conv3x3_1'] = head_cmp
    dist_cmprate['head_bbox_conv3x3_2'] = head_cmp
    dist_cmprate['head_bbox_conv3x3_3'] = head_cmp
    dist_cmprate['head_cls_conv3x3_1'] = head_cmp
    dist_cmprate['head_cls_conv3x3_2'] = head_cmp
    dist_cmprate['head_cls_conv3x3_3'] = head_cmp

def get_value():
    try:
        return dist_cmprate
    except:
        print('read' + ' error\n')